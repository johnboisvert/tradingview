"""
Vidéos YouTube en français pour l'Academy Trading
Vidéos éducatives sur le trading crypto en français
URLs fournies par l'utilisateur - Contenu vérifié en français
"""

# Structure: (module_id, lesson_id): "youtube_embed_url"
# Format embed: https://www.youtube.com/embed/VIDEO_ID

# Vidéos YouTube françaises - URLs officielles fournies
YOUTUBE_VIDEOS = {
    # ============================================
    # MODULE 1: Introduction au Trading Crypto
    # Vidéo: https://youtu.be/TbKgV8mZvOE
    # ============================================
    
    (1, 1): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 2): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 3): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 4): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 5): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 6): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 7): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (1, 8): "https://www.youtube.com/embed/TbKgV8mZvOE",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 2: Lecture des Graphiques
    # Vidéo: https://youtu.be/zAjemUdp2bc
    # ============================================
    
    (2, 1): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 2): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 3): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 4): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 5): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 6): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 7): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 8): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 9): "https://www.youtube.com/embed/zAjemUdp2bc",
    (2, 10): "https://www.youtube.com/embed/zAjemUdp2bc",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 3: Gestion du Capital (Money Management)
    # Vidéo: https://youtu.be/berx5Yna0Lw
    # ============================================
    
    (3, 1): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 2): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 3): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 4): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 5): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 6): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 7): "https://www.youtube.com/embed/berx5Yna0Lw",
    (3, 8): "https://www.youtube.com/embed/berx5Yna0Lw",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 4: Types d'Ordres
    # Vidéo: https://youtu.be/ruPNWEuwrcg
    # ============================================
    
    (4, 1): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 2): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 3): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 4): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 5): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 6): "https://www.youtube.com/embed/ruPNWEuwrcg",
    (4, 7): "https://www.youtube.com/embed/ruPNWEuwrcg",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 5: Sécurité & Wallets
    # Vidéo: https://youtu.be/_V0GMPq-MLQ
    # ============================================
    
    (5, 1): "https://www.youtube.com/embed/_V0GMPq-MLQ",
    (5, 2): "https://www.youtube.com/embed/_V0GMPq-MLQ",
    (5, 3): "https://www.youtube.com/embed/_V0GMPq-MLQ",
    (5, 4): "https://www.youtube.com/embed/_V0GMPq-MLQ",
    (5, 5): "https://www.youtube.com/embed/_V0GMPq-MLQ",
    (5, 6): "https://www.youtube.com/embed/_V0GMPq-MLQ",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 6: Psychologie du Trader
    # Vidéo: https://youtu.be/L3ZvYq-5IfM
    # ============================================
    
    (6, 1): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 2): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 3): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 4): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 5): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 6): "https://www.youtube.com/embed/L3ZvYq-5IfM",
    (6, 7): "https://www.youtube.com/embed/L3ZvYq-5IfM",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 7: Supports & Résistances
    # Vidéo: https://youtu.be/CnRVH8AxQgw
    # ============================================
    
    (7, 1): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 2): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 3): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 4): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 5): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 6): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 7): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 8): "https://www.youtube.com/embed/CnRVH8AxQgw",
    (7, 9): "https://www.youtube.com/embed/CnRVH8AxQgw",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 8: Indicateurs Techniques
    # Vidéo: https://youtu.be/e8R5xIGY77U
    # ============================================
    
    (8, 1): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 2): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 3): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 4): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 5): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 6): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 7): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 8): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 9): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 10): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 11): "https://www.youtube.com/embed/e8R5xIGY77U",
    (8, 12): "https://www.youtube.com/embed/e8R5xIGY77U",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 9: Patterns Chartistes
    # Vidéo: https://youtu.be/lUx_llrNyt4
    # ============================================
    
    (9, 1): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 2): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 3): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 4): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 5): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 6): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 7): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 8): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 9): "https://www.youtube.com/embed/lUx_llrNyt4",
    (9, 10): "https://www.youtube.com/embed/lUx_llrNyt4",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 10: Chandeliers Avancés
    # Vidéo: https://youtu.be/mott_H1JgQY
    # ============================================
    
    (10, 1): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 2): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 3): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 4): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 5): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 6): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 7): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 8): "https://www.youtube.com/embed/mott_H1JgQY",
    (10, 9): "https://www.youtube.com/embed/mott_H1JgQY",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 11: Fibonacci & Retracements
    # Vidéo: https://youtu.be/-CRPKBSqDm8
    # ============================================
    
    (11, 1): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 2): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 3): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 4): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 5): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 6): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 7): "https://www.youtube.com/embed/-CRPKBSqDm8",
    (11, 8): "https://www.youtube.com/embed/-CRPKBSqDm8",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 12: Analyse des Volumes
    # Vidéo: https://youtu.be/9TZGZeeoOkI
    # ============================================
    
    (12, 1): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 2): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 3): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 4): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 5): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 6): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 7): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 8): "https://www.youtube.com/embed/9TZGZeeoOkI",
    (12, 9): "https://www.youtube.com/embed/9TZGZeeoOkI",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 13: Scalping & Day Trading
    # Vidéo: https://youtu.be/EmguuNvMsSQ
    # ============================================
    
    (13, 1): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 2): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 3): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 4): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 5): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 6): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 7): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 8): "https://www.youtube.com/embed/EmguuNvMsSQ",
    (13, 9): "https://www.youtube.com/embed/EmguuNvMsSQ",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 14: Swing Trading
    # Vidéo: https://youtu.be/9zUmdAUy_Zs
    # ============================================
    
    (14, 1): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 2): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 3): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 4): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 5): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 6): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 7): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 8): "https://www.youtube.com/embed/9zUmdAUy_Zs",
    (14, 9): "https://www.youtube.com/embed/9zUmdAUy_Zs",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 15: Trading de Breakout
    # Vidéo: https://youtu.be/qbwrVRVOr_c
    # ============================================
    
    (15, 1): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 2): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 3): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 4): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 5): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 6): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 7): "https://www.youtube.com/embed/qbwrVRVOr_c",
    (15, 8): "https://www.youtube.com/embed/qbwrVRVOr_c",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 16: Risk Management Pro
    # Vidéo: https://youtu.be/c0zJ8e78QEk
    # ============================================
    
    (16, 1): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 2): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 3): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 4): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 5): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 6): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 7): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 8): "https://www.youtube.com/embed/c0zJ8e78QEk",
    (16, 9): "https://www.youtube.com/embed/c0zJ8e78QEk",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 17: Trading Mobile & Alertes
    # Vidéo: https://youtu.be/ag_ltDjnrpE
    # ============================================
    
    (17, 1): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 2): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 3): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 4): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 5): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 6): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 7): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 8): "https://www.youtube.com/embed/ag_ltDjnrpE",
    (17, 9): "https://www.youtube.com/embed/ag_ltDjnrpE",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 18: Trading avec l'IA
    # Vidéo: https://youtu.be/rDHma8ximZ4
    # ============================================
    
    (18, 1): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 2): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 3): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 4): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 5): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 6): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 7): "https://www.youtube.com/embed/rDHma8ximZ4",
    (18, 8): "https://www.youtube.com/embed/rDHma8ximZ4",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 19: Analyse On-Chain
    # Vidéo: https://youtu.be/_5C9Tv92WvY
    # ============================================
    
    (19, 1): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 2): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 3): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 4): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 5): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 6): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 7): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 8): "https://www.youtube.com/embed/_5C9Tv92WvY",
    (19, 9): "https://www.youtube.com/embed/_5C9Tv92WvY",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 20: DeFi & Yield Farming
    # Vidéo: https://youtu.be/XLrDVYBP6cY
    # ============================================
    
    (20, 1): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 2): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 3): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 4): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 5): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 6): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 7): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 8): "https://www.youtube.com/embed/XLrDVYBP6cY",
    (20, 9): "https://www.youtube.com/embed/XLrDVYBP6cY",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 21: Détection de Gems
    # Vidéo: https://youtu.be/zw0F1L5HMFY
    # ============================================
    
    (21, 1): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 2): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 3): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 4): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 5): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 6): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 7): "https://www.youtube.com/embed/zw0F1L5HMFY",
    (21, 8): "https://www.youtube.com/embed/zw0F1L5HMFY",  # Quiz - même vidéo que le module
    
    # ============================================
    # MODULE 22: Masterclass Trading Pro
    # Vidéo: https://youtu.be/TbKgV8mZvOE
    # ============================================
    
    (22, 1): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 2): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 3): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 4): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 5): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 6): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 7): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 8): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 9): "https://www.youtube.com/embed/TbKgV8mZvOE",
    (22, 10): "https://www.youtube.com/embed/TbKgV8mZvOE",  # Quiz - même vidéo que le module
}

def get_video_url(module_id: int, lesson_id: int) -> str:
    """Récupère l'URL de la vidéo YouTube pour une leçon."""
    return YOUTUBE_VIDEOS.get((module_id, lesson_id), "")